import csv

# Function to split a name into first name and last name
def split_name(name):
    parts = name.split()
    if len(parts) == 2:
        first_name, last_name = parts
    else:
        first_name = name
        last_name = "Null"  # If there's no last name, set it to "Null"
    return first_name, last_name

# Open the CSV file for reading and the output file for writing
with open('wwc.csv', 'r', newline='') as input_file, open('output.csv', 'w') as output_file:
    # Create CSV reader and writer objects
    csv_reader = csv.reader(input_file)
    csv_writer = csv.writer(output_file, delimiter='\t')  # Use tab as a delimiter in the output

    for row in csv_reader:
        if len(row) > 18:  # Ensure that there are at least 19 columns in the row
            referee_name = row[18]  # Assuming the referee's name is in the 19th column
            first_name, last_name = split_name(referee_name)
            csv_writer.writerow([first_name, last_name])

print("Referee names split and written to output.txt")
