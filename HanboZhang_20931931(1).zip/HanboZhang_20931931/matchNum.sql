-- this matchNum file will display how many matches are in each WorldCup in decending order

SELECT Year, COUNT(*) AS matches_played
FROM FootballMatch
GROUP BY Year
ORDER BY matches_played DESC;
