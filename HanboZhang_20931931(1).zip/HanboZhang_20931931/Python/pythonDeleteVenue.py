import mysql.connector


conn = mysql.connector.connect(
    host="localhost",
    user="me",
    password="myUserPassword",
    database="worldcup_20931931"
)
cursor = conn.cursor()

venueName_to_delete = input("Enter the venue name to delete: ")
condition = "venueName = %s"

value = (venueName_to_delete,)

delete_query = f"DELETE FROM Venue WHERE {condition}"

cursor.execute(delete_query, value)

conn.commit()

cursor.close()
conn.close()
