import mysql.connector
conn = mysql.connector.connect(
    host="localhost",
    user="me",
    password="myUserPassword",
    database="worldcup_20931931"
)
# this is to create a cursor object to interact with the database
cursor = conn.cursor()
# Ask the user for input
venueName = input("Enter venue name: ")
venueCity = input("Enter venue city: ")
hostCountry = input("Enter host country: ")
# get data from user
data = {
    'venueName': venueName,
    'venueCity': venueCity,
    'hostCountry': hostCountry
}
# For the following code SQL query to insert data into the Venue table
insert_query = "INSERT INTO Venue (venueName, venueCity, hostCountry) VALUES (%(venueName)s, %(venueCity)s, %(hostCountry)s)"
# And execute the query and insert the data
cursor.execute(insert_query, data)
# Commit the changes to the database
conn.commit()
# Close the cursor and connection
cursor.close()
conn.close()
