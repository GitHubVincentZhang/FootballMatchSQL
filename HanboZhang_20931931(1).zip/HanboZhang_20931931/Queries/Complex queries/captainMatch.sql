-- welcome to captainMatch file, after you source this sql file, you will be able to get a list of captain name, teamname and how many match these teams have played in a decending order. 
SELECT t.captain, t.teamName, COUNT(*) AS matches_played
FROM Team t
LEFT JOIN FootballMatch fm ON t.teamName = fm.teamID_home OR t.teamName = fm.teamID_away
GROUP BY t.captain, t.teamName
ORDER BY matches_played DESC;
