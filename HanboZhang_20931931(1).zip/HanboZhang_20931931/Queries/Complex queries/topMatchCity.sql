
-- this is a mysql file that you can see a list of venues and how many matches have happened in there in a decending order
SELECT venueCity, COUNT(*) AS matches_played
FROM Venue
LEFT JOIN FootballMatch ON Venue.venueName = FootballMatch.venueName
GROUP BY venueCity
ORDER BY matches_played DESC;

