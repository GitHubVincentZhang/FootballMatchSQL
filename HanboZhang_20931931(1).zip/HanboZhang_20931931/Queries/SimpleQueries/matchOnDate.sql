-- welcome to matchOnDate file, this program is to pull out all match that happened on a specific date, in the file, I have used

SELECT *
FROM FootballMatch
WHERE match_date > '2023-08-07';
