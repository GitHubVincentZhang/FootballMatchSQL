import mysql.connector
conn = mysql.connector.connect(
    host="your_host",
    user="your_username",
    password="your_password",
    database="your_database"
)
cursor = conn.cursor()
venueName = input("Enter venue name to update: ")
newVenueCity = input("Enter the new venue city: ")
newHostCountry = input("Enter the new host country: ")
data = {
    'venueCity': newVenueCity,
    'hostCountry': newHostCountry,
    'venueName': venueName
}
update_query = "UPDATE Venue SET venueCity = %(venueCity)s, hostCountry = %(hostCountry)s WHERE venueName = %(venueName)s"
cursor.execute(update_query, data)
conn.commit()
# Close the cursor and connection
cursor.close()
conn.close()
