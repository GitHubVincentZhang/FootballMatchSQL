-- welcome to mostPlayTeam file, after user surce this file, user will be able to see the team that has played the most matches and the rest in a decending order
SELECT teamID_home AS teamID, COUNT(*) AS matches_played
FROM FootballMatch
GROUP BY teamID
UNION ALL
SELECT teamID_away AS teamID, COUNT(*) AS matches_played
FROM FootballMatch
GROUP BY teamID
ORDER BY matches_played DESC;
