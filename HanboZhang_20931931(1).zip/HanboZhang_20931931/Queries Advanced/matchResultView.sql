CREATE OR REPLACE VIEW MatchResultsView AS
SELECT
    M.matchID,
    M.match_date,
    T1.teamName AS homeTeam,
    T2.teamName AS awayTeam,
    M.venueName,
    V.venueCity,
    WC.HostCountry AS worldCupHost,
    WC.Champion AS worldCupChampion
FROM FootballMatch M
JOIN Team T1 ON M.teamID_home = T1.teamName
JOIN Team T2 ON M.teamID_away = T2.teamName
JOIN Venue V ON M.venueName = V.venueName
JOIN WorldCup WC ON M.Year = WC.Year;
