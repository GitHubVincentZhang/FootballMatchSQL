-- I have created a procedure to insert term table. 

DELIMITER $$
CREATE PROCEDURE InsertNewTeam(IN teamName VARCHAR(50), IN captain VARCHAR(50))
BEGIN
    INSERT INTO Team (teamName, captain) VALUES (teamName, captain);
END$$
DELIMITER ;

