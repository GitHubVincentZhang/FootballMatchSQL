CREATE VIEW PlayerTeamInfo AS
SELECT
    P.teamName,
    P.playerID,
    P.firstName,
    P.lastName,
    T.captain,
    T1.captain AS teamCaptain
FROM Player P
JOIN Team T ON P.teamName = T.teamName
LEFT JOIN Team T1 ON T.captain = T1.captain;
