import pandas as pd
import mysql.connector

# Establish a MySQL connection
db_connection = mysql.connector.connect(
    host='localhost',
    user='me',
    password='myUserPassword',
    database='worldcup_20931931'
)

# Read the CSV file into a DataFrame
csv_file = 'realmatch.csv'
df = pd.read_csv(csv_file)

# Insert data into MySQL table
table_name = 'FootballMatch'
df.to_sql(con=db_connection, name=table_name, if_exists='replace', index=False)

# Commit changes and close the connection
db_connection.commit()
db_connection.close()
