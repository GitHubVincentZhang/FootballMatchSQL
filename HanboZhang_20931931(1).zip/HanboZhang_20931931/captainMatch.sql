-- welcome to captainMatch program, this will show you the captain name and the number of matches played by their teams. 
SELECT t.captain, t.teamName, COUNT(*) AS matches_played
FROM Team t
LEFT JOIN FootballMatch fm ON t.teamName = fm.teamID_home OR t.teamName = fm.teamID_away
GROUP BY t.captain, t.teamName
ORDER BY matches_played DESC;
