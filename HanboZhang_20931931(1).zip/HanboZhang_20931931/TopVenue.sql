--welcome to TopVenue, you can source this file after running build.sql(creating databases, tables, and inserting values)
--this is a mysql file which can find out the venue that had the most matches. 

SELECT venueName, COUNT(*) AS matches_played
FROM FootballMatch
GROUP BY venueName
ORDER BY matches_played DESC
LIMIT 1;
