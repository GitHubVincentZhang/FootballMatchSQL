CREATE DATABASE IF NOT EXISTS worldcup_20931931;
USE worldcup_20931931;

DROP TABLE IF EXISTS MatchReferee;
DROP TABLE IF EXISTS Player;
DROP TABLE IF EXISTS FootballMatch;
DROP TABLE IF EXISTS Team;
DROP TABLE IF EXISTS Venue;
DROP TABLE IF EXISTS WorldCup;
DROP TABLE IF EXISTS Referee;

CREATE TABLE WorldCup (
    Year INT PRIMARY KEY,
    HostCountry VARCHAR(50),
    Champion VARCHAR(50)
);

CREATE TABLE Venue (
    venueName VARCHAR(50) NOT NULL,
    venueCity VARCHAR(50) NOT NULL,
    hostCountry VARCHAR(30) NOT NULL,
    PRIMARY KEY (venueName)
);

CREATE TABLE Team (
    teamID INT NOT NULL,
    teamName VARCHAR(50) NOT NULL,
    captain VARCHAR(50) NOT NULL,
    PRIMARY KEY (teamID)
);

CREATE TABLE FootballMatch (
    matchID INT PRIMARY KEY,
    teamID_home INT NOT NULL,
    teamID_away INT NOT NULL,
    venueName VARCHAR(50) NOT NULL,
    match_date DATE,
    Year INT NOT NULL,
    FOREIGN KEY (teamID_home) REFERENCES Team(teamID),
    FOREIGN KEY (teamID_away) REFERENCES Team(teamID),
    FOREIGN KEY (venueName) REFERENCES Venue(venueName),
    FOREIGN KEY (Year) REFERENCES WorldCup(Year)
);


CREATE TABLE Player (
    teamID INT,
    playerID INT,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    PRIMARY KEY (teamID, playerID),
    FOREIGN KEY (teamID) REFERENCES Team(teamID)
);

CREATE TABLE Referee (
    refereeID INT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL
);

CREATE TABLE MatchReferee (
    matchID INT,
    refereeID INT,
    PRIMARY KEY (matchID, refereeID),
    FOREIGN KEY (matchID) REFERENCES FootballMatch(matchID),
    FOREIGN KEY (refereeID) REFERENCES Referee(refereeID)
);
