-- after creating a new team, this database will automatically create a new player with the name of Captain and '1' as player ID

DELIMITER //
CREATE TRIGGER InsertCaptain
AFTER INSERT ON Team
FOR EACH ROW
BEGIN
    INSERT INTO Player (teamName, playerID, firstName, lastName)
    VALUES (NEW.teamName, 1, NEW.captain, 'Captain');
END;
//
DELIMITER ;
