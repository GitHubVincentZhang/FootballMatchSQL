-- this getMatchByTeam sql file will show you all matches that a specific team has participated
-- and the output is in decending order


SELECT *
FROM FootballMatch
WHERE teamID_home = 'England' OR teamID_away = 'England'
ORDER BY match_date DESC;


