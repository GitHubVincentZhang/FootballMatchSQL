-- welcome to topMatchCity file, the program is to get the city where the most match happened and other ones in decending order

SELECT venueCity, COUNT(*) AS matches_played
FROM Venue
LEFT JOIN FootballMatch ON Venue.venueName = FootballMatch.venueName
GROUP BY venueCity
ORDER BY matches_played DESC;

