import pandas as pd

df = pd.read_csv('wwc.csv')

df[['Stadium', 'City']] = df['Venue'].str.split(', ', expand=True)
df.drop(columns=['Venue'], inplace=True)

df[['Stadium','City','Host']].head(200).to_csv('home_teams.csv',index=False)
