import csv

input_file = 'output.csv'  # Replace with the actual file name
output_file = 'outputReferee.csv'  # Replace with the desired output file name

# Open the input CSV file for reading and the output CSV file for writing
with open(input_file, 'r', newline='') as input_csv, open(output_file, 'w', newline='') as output_csv:
    csv_reader = csv.reader(input_csv)
    csv_writer = csv.writer(output_csv)

    seen_rows = set()  # To keep track of the rows seen so far

    for row in csv_reader:
        row_str = ','.join(row)  # Convert the row to a string for set comparison
        if row_str not in seen_rows:
            seen_rows.add(row_str)  # Add this row to the set of seen rows
            csv_writer.writerow(row)

print("Duplicate rows removed. Output saved to", output_file)
