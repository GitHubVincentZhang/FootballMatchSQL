-- this championCaptain program is to get the champion team captain name for a specific year(2019)
SELECT t.captain
FROM Team t
JOIN WorldCup wc ON t.teamName = wc.Champion
WHERE wc.Year = 2019;
