INSERT INTO WorldCup (Year, HostCountry, Champion) VALUES
    (1991, 'China', 'United States'),
    (1995, 'Sweden', 'Norway'),
    (1999, 'United States', 'United States'),
    (2003, 'United States', 'Germany'),
    (2007, 'China', 'Germany'),
    (2011, 'Germany', 'Japan'),
    (2015, 'Canada', 'United States'),
    (2019, 'France', 'United States'),
    (2023, 'Australia and New Zealand', 'Spain');
