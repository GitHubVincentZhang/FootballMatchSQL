INSERT INTO Player (teamName, playerID, firstName, lastName)
VALUES
    -- Spain
    ('Spain', 1, 'Isabella', 'Rodriguez'),
    ('Spain', 2, 'Mateo', 'Lopez'),
    ('Spain', 3, 'Sofia', 'Garcia'),
    ('Spain', 4, 'Alejandro', 'Torres'),
    ('Spain', 5, 'Luna', 'Rodriguez'),
    ('Spain', 6, 'Diego', 'Martinez'),
    ('Spain', 7, 'Valentina', 'Fernandez'),
    ('Spain', 8, 'Lucas', 'Sanchez'),

    -- Australia
    ('Australia', 1, 'Liam', 'Smith'),
    ('Australia', 2, 'Olivia', 'Wilson'),
    ('Australia', 3, 'Jack', 'Turner'),
    ('Australia', 4, 'Zoe', 'Harris'),
    ('Australia', 5, 'Ethan', 'Brown'),
    ('Australia', 6, 'Mia', 'Jones'),
    ('Australia', 7, 'Liam', 'Smith'),
    ('Australia', 8, 'Isabella', 'White'),

    -- England
    ('England', 1, 'Olivia', 'Johnson'),
    ('England', 2, 'Harry', 'Taylor'),
    ('England', 3, 'Emily', 'Johnson'),
    ('England', 4, 'Charlie', 'Harris'),
    ('England', 5, 'Sophie', 'Smith'),
    ('England', 6, 'Noah', 'Davis'),
    ('England', 7, 'Amelia', 'Roberts'),
    ('England', 8, 'Jack', 'Wilson'),

    -- Japan
    ('Japan', 1, 'Yuki', 'Suzuki'),
    ('Japan', 2, 'Hiroshi', 'Sato'),
    ('Japan', 3, 'Akihiko', 'Takahashi'),
    ('Japan', 4, 'Yui', 'Nakamura'),
    ('Japan', 5, 'Miyuki', 'Kobayashi'),
    ('Japan', 6, 'Kazuki', 'Yamamoto'),
    ('Japan', 7, 'Makoto', 'Ito'),
    ('Japan', 8, 'Nanami', 'Suzuki'),

    -- Colombia
    ('Colombia', 1, 'Camila', 'Gomez'),
    ('Colombia', 2, 'Carlos', 'Gomez'),
    ('Colombia', 3, 'Maria', 'Hernandez'),
    ('Colombia', 4, 'Juan', 'Lopez'),
    ('Colombia', 5, 'Laura', 'Rodriguez'),
    ('Colombia', 6, 'Andres', 'Garcia'),
    ('Colombia', 7, 'Sofia', 'Martinez'),
    ('Colombia', 8, 'Luis', 'Diaz'),

    -- France
    ('France', 1, 'Lucas', 'Martin'),
    ('France', 2, 'Lucie', 'Lecomte'),
    ('France', 3, 'Thomas', 'Dubois'),
    ('France', 4, 'Chloe', 'Martin'),
    ('France', 5, 'Antoine', 'Girard'),
    ('France', 6, 'Manon', 'Petit'),
    ('France', 7, 'Hugo', 'Dufresne'),
    ('France', 8, 'Camille', 'Leroux'),

    -- Netherlands
    ('Netherlands', 1, 'Sophie', 'de Boer'),
    ('Netherlands', 2, 'Daan', 'Janssen'),
    ('Netherlands', 3, 'Eva', 'van der Berg'),
    ('Netherlands', 4, 'Thijs', 'van Dijk'),
    ('Netherlands', 5, 'Lotte', 'Bakker'),
    ('Netherlands', 6, 'Sem', 'de Vries'),
    ('Netherlands', 7, 'Isabelle', 'Meijer'),
    ('Netherlands', 8, 'Luuk', 'Hendriks'),

    -- Switzerland
    ('Switzerland', 1, 'Lukas', 'Müller'),
    ('Switzerland', 2, 'Lara', 'Meyer'),
    ('Switzerland', 3, 'Noah', 'Schmidt'),
    ('Switzerland', 4, 'Elena', 'Zimmermann'),
    ('Switzerland', 5, 'Tim', 'Keller'),
    ('Switzerland', 6, 'Sophie', 'Müller'),
    ('Switzerland', 7, 'Liam', 'Hofmann'),
    ('Switzerland', 8, 'Lea', 'Fischer'),

    -- Morocco
    ('Morocco', 1, 'Amina', 'El-Abidin'),
    ('Morocco', 2, 'Youssef', 'El-Abidin'),
    ('Morocco', 3, 'Sara', 'Bouhaddi'),
    ('Morocco', 4, 'Ahmed', 'Hakimi'),
    ('Morocco', 5, 'Leila', 'Zidane'),
    ('Morocco', 6, 'Mohammed', 'Belhanda'),
    ('Morocco', 7, 'Sofia', 'Chakir'),
    ('Morocco', 8, 'Younes', 'Nasri'),

    -- Korea Republic
    ('Korea Republic', 1, 'Ji-eun', 'Kim'),
    ('Korea Republic', 2, 'Ji-eun', 'Kim'),
    ('Korea Republic', 3, 'Sung-hoon', 'Park'),
    ('Korea Republic', 4, 'Min-ji', 'Choi'),
    ('Korea Republic', 5, 'Hyun-woo', 'Lee'),
    ('Korea Republic', 6, 'Yoon-joo', 'Kang'),
    ('Korea Republic', 7, 'Seung-yeon', 'Han'),
    ('Korea Republic', 8, 'Jae-ho', 'Yoon'),

    -- South Africa
    ('South Africa', 1, 'Thembi', 'Kgatlana'),
    ('South Africa', 2, 'Thabo', 'Dube'),
    ('South Africa', 3, 'Lerato', 'Mkhize'),
    ('South Africa', 4, 'Sipho', 'Nkosi'),
    ('South Africa', 5, 'Nandi', 'Modise'),
    ('South Africa', 6, 'Mandla', 'Khumalo'),
    ('South Africa', 7, 'Thandeka', 'Zulu'),
    ('South Africa', 8, 'Sifiso', 'Mazibuko'),

    -- Argentina
    ('Argentina', 1, 'Vanina', 'Correa'),
    ('Argentina', 2, 'Diego', 'Lopez'),
    ('Argentina', 3, 'Maria', 'Gonzalez'),
    ('Argentina', 4, 'Juan', 'Fernandez'),
    ('Argentina', 5, 'Laura', 'Martinez'),
    ('Argentina', 6, 'Carlos', 'Rodriguez'),
    ('Argentina', 7, 'Sofia', 'Diaz'),
    ('Argentina', 8, 'Luis', 'Santos'),

    -- Panama
    ('Panama', 1, 'Marta', 'Cox'),
    ('Panama', 2, 'Ana', 'Herrera'),
    ('Panama', 3, 'Carlos', 'Gonzalez'),
    ('Panama', 4, 'Maria', 'Lopez'),
    ('Panama', 5, 'Juan', 'Perez'),
    ('Panama', 6, 'Sofia', 'Martinez'),
    ('Panama', 7, 'Luis', 'Fernandez'),
    ('Panama', 8, 'Camila', 'Ramirez'),

    -- Vietnam
    ('Vietnam', 1, 'Pham', 'Hai Yen'),
    ('Vietnam', 2, 'Pham', 'Tran'),
    ('Vietnam', 3, 'Nguyen', 'Le'),
    ('Vietnam', 4, 'Trang', 'Nguyen'),
    ('Vietnam', 5, 'Minh', 'Pham'),
    ('Vietnam', 6, 'Hoa', 'Vu'),
    ('Vietnam', 7, 'Thao', 'Bui'),
    ('Vietnam', 8, 'Dat', 'Nguyen'),

    -- Haiti
    ('Haiti', 1, 'Nerilia', 'Mondesir'),
    ('Haiti', 2, 'Marie', 'Pierre'),
    ('Haiti', 3, 'Jean', 'Michel'),
    ('Haiti', 4, 'Luis', 'Lafontant'),
    ('Haiti', 5, 'Sophie', 'Joseph'),
    ('Haiti', 6, 'David', 'Desir'),
    ('Haiti', 7, 'Sandra', 'Louis'),
    ('Haiti', 8, 'Jeanne', 'Francois'),

    -- Costa Rica
    ('Costa Rica', 1, 'Katherine', 'Alvarado'),
    ('Costa Rica', 2, 'Carlos', 'Ramirez'),
    ('Costa Rica', 3, 'Sofia', 'Lopez'),
    ('Costa Rica', 4, 'Luis', 'Gonzalez'),
    ('Costa Rica', 5, 'Maria', 'Rodriguez'),
    ('Costa Rica', 6, 'Juan', 'Herrera'),
    ('Costa Rica', 7, 'Sara', 'Fernandez'),
    ('Costa Rica', 8, 'Diego', 'Mora'),

    -- Republic of Ireland
    ('Republic of Ireland', 1, 'Katie', 'McCabe'),
    ('Republic of Ireland', 2, 'Ella', 'Murphy'),
    ('Republic of Ireland', 3, 'Jack', 'Doherty'),
    ('Republic of Ireland', 4, 'Sophie', 'OSullivan'),
    ('Republic of Ireland', 5, 'Liam', 'Ryan'),
    ('Republic of Ireland', 6, 'Emily', 'McCarthy'),
    ('Republic of Ireland', 7, 'Ciaran', 'Walsh'),
    ('Republic of Ireland', 8, 'Ava', 'Nolan'),

    -- Canada
    ('Canada', 1, 'Christine', 'Sinclair'),
    ('Canada', 2, 'Aiden', 'Robinson'),
    ('Canada', 3, 'Olivia', 'Miller'),
    ('Canada', 4, 'Ethan', 'Smith'),
    ('Canada', 5, 'Sophie', 'Larson'),
    ('Canada', 6, 'Liam', 'Williams'),
    ('Canada', 7, 'Isabella', 'Brown'),
    ('Canada', 8, 'Lucas', 'Anderson'),

    -- Norway
    ('Norway', 1, 'Maren', 'Mjelde'),
    ('Norway', 2, 'Ingrid', 'Haugen'),
    ('Norway', 3, 'Sofia', 'Olsen'),
    ('Norway', 4, 'Lars', 'Johansen'),
    ('Norway', 5, 'Mia', 'Pedersen'),
    ('Norway', 6, 'Erik', 'Andersson'),
    ('Norway', 7, 'Astrid', 'Hansen'),
    ('Norway', 8, 'Nora', 'Sørensen'),

    -- Germany
    ('Germany', 1, 'Alexandra', 'Popp'),
    ('Germany', 2, 'Mia', 'Schmidt'),
    ('Germany', 3, 'Lukas', 'Becker'),
    ('Germany', 4, 'Sophie', 'Müller'),
    ('Germany', 5, 'Noah', 'Schulz'),
    ('Germany', 6, 'Emma', 'Wagner'),
    ('Germany', 7, 'Leon', 'Hoffmann'),
    ('Germany', 8, 'Lena', 'Meier'),

    -- Portugal
    ('Portugal', 1, 'Ana', 'Borges'),
    ('Portugal', 2, 'Ricardo', 'Fernandes'),
    ('Portugal', 3, 'Sofia', 'Silva'),
    ('Portugal', 4, 'Lucas', 'Mendes'),
    ('Portugal', 5, 'Inês', 'Carvalho'),
    ('Portugal', 6, 'Tiago', 'Pereira'),
    ('Portugal', 7, 'Ana', 'Ribeiro'),
    ('Portugal', 8, 'João', 'Martins'),

    -- New Zealand
    ('New Zealand', 1, 'Ria', 'Percival'),
    ('New Zealand', 2, 'Ella', 'Brown'),
    ('New Zealand', 3, 'Liam', 'Smith'),
    ('New Zealand', 4, 'Isabella', 'Jones'),
    ('New Zealand', 5, 'Lucas', 'Wilson'),
    ('New Zealand', 6, 'Sophie', 'Davis'),
    ('New Zealand', 7, 'Noah', 'Thompson'),
    ('New Zealand', 8, 'Olivia', 'Anderson'),

    -- Italy
    ('Italy', 1, 'Barbara', 'Bonansea'),
    ('Italy', 2, 'Giuseppe', 'Conti'),
    ('Italy', 3, 'Lucia', 'Ricci'),
    ('Italy', 4, 'Matteo', 'Rossi'),
    ('Italy', 5, 'Sofia', 'Ferrari'),
    ('Italy', 6, 'Alessio', 'Marino'),
    ('Italy', 7, 'Francesca', 'Barbieri'),
    ('Italy', 8, 'Giovanni', 'Romano'),

    -- Brazil
    ('Brazil', 1, 'Rafaelle', 'Sousa'),
    ('Brazil', 2, 'Lucia', 'Silva'),
    ('Brazil', 3, 'Gabriel', 'Oliveira'),
    ('Brazil', 4, 'Ana', 'Pereira'),
    ('Brazil', 5, 'Luiz', 'Santos'),
    ('Brazil', 6, 'Mariana', 'Cunha'),
    ('Brazil', 7, 'Carlos', 'Rocha'),
    ('Brazil', 8, 'Juliana', 'Ferreira'),

    -- Zambia
    ('Zambia', 1, 'Barbra', 'Banda'),
    ('Zambia', 2, 'Chanda', 'Mwansa'),
    ('Zambia', 3, 'Moses', 'Banda'),
    ('Zambia', 4, 'Mary', 'Mulenga'),
    ('Zambia', 5, 'Kingsley', 'Nkosi'),
    ('Zambia', 6, 'Ruth', 'Chibwe'),
    ('Zambia', 7, 'Elijah', 'Sakala'),
    ('Zambia', 8, 'Esther', 'Chanda'),

    -- Denmark
    ('Denmark', 1, 'Pernille', 'Harder'),
    ('Denmark', 2, 'Lars', 'Jensen'),
    ('Denmark', 3, 'Mette', 'Hansen'),
    ('Denmark', 4, 'Anders', 'Nielsen'),
    ('Denmark', 5, 'Camilla', 'Sørensen'),
    ('Denmark', 6, 'Søren', 'Pedersen'),
    ('Denmark', 7, 'Louise', 'Andersen'),
    ('Denmark', 8, 'Rasmus', 'Larsen'),

    -- Nigeria
    ('Nigeria', 1, 'Chiamaka', 'Nnadozie'),
    ('Nigeria', 2, 'Chidinma', 'Okonkwo'),
    ('Nigeria', 3, 'Musa', 'Abubakar'),
    ('Nigeria', 4, 'Amina', 'Okafor'),
    ('Nigeria', 5, 'Yusuf', 'Ibrahim'),
    ('Nigeria', 6, 'Fatimah', 'Adewale'),
    ('Nigeria', 7, 'Chukwudi', 'Nwosu'),
    ('Nigeria', 8, 'Linda', 'Eze'),

    -- Philippines
    ('Philippines', 1, 'Hali', 'Long'),
    ('Philippines', 2, 'Jose', 'Santos'),
    ('Philippines', 3, 'Maria', 'Garcia'),
    ('Philippines', 4, 'Carlos', 'Reyes'),
    ('Philippines', 5, 'Sofia', 'Dela Cruz'),
    ('Philippines', 6, 'Juan', 'Mendoza'),
    ('Philippines', 7, 'Sara', 'Torres'),
    ('Philippines', 8, 'Luis', 'Lopez'),

    -- Cameroon
    ('Cameroon', 1, 'Gabrielle', 'Onguene'),
    ('Cameroon', 2, 'Achille', 'Ngo'),
    ('Cameroon', 3, 'Marie', 'Fotso'),
    ('Cameroon', 4, 'Jean', 'Tchami'),
    ('Cameroon', 5, 'Sofia', 'Makinde'),
    ('Cameroon', 6, 'Lucas', 'Nkoudou'),
    ('Cameroon', 7, 'Esther', 'Njock'),
    ('Cameroon', 8, 'Pierre', 'Moukandjo'),

    -- Scotland
    ('Scotland', 1, 'Rachel', 'Corsie'),
    ('Scotland', 2, 'Fiona', 'MacLeod'),
    ('Scotland', 3, 'Euan', 'MacDonald'),
    ('Scotland', 4, 'Katie', 'Smith'),
    ('Scotland', 5, 'Calum', 'Brown'),
    ('Scotland', 6, 'Mhairi', 'Wilson'),
    ('Scotland', 7, 'Angus', 'McKay'),
    ('Scotland', 8, 'Caitlin', 'Stewart'),

    -- China PR
    ('China PR', 1, 'Wu', 'Haiyan'),
    ('China PR', 2, 'Wei', 'Li'),
    ('China PR', 3, 'Xiao', 'Chen'),
    ('China PR', 4, 'Jing', 'Wang'),
    ('China PR', 5, 'Chao', 'Zhang'),
    ('China PR', 6, 'Min', 'Liu'),
    ('China PR', 7, 'Qing', 'Huang'),
    ('China PR', 8, 'Xin', 'Yang'),

    -- Sweden
    ('Sweden', 1, 'Caroline', 'Seger'),
    ('Sweden', 2, 'Erik', 'Andersson'),
    ('Sweden', 3, 'Sofia', 'Larsson'),
    ('Sweden', 4, 'Lukas', 'Nilsson'),
    ('Sweden', 5, 'Mia', 'Gustafsson'),
    ('Sweden', 6, 'Isak', 'Johansson'),
    ('Sweden', 7, 'Astrid', 'Karlsson'),
    ('Sweden', 8, 'Oskar', 'Svensson'),

    -- Jamaica
    ('Jamaica', 1, 'Khadija', 'Shaw'),
    ('Jamaica', 2, 'Leon', 'Morgan'),
    ('Jamaica', 3, 'Ricardo', 'Williams'),
    ('Jamaica', 4, 'Sydney', 'Lewis'),
    ('Jamaica', 5, 'Samantha', 'Clarke'),
    ('Jamaica', 6, 'Kwame', 'Miller'),
    ('Jamaica', 7, 'Shanice', 'Grant'),
    ('Jamaica', 8, 'Dwayne', 'Brown'),

    -- Mexico
    ('Mexico', 1, 'Monica', 'Ocampo'),
    ('Mexico', 2, 'Carlos', 'Garcia'),
    ('Mexico', 3, 'Ana', 'Hernandez'),
    ('Mexico', 4, 'Luis', 'Lopez'),
    ('Mexico', 5, 'Sofia', 'Mendoza'),
    ('Mexico', 6, 'Diego', 'Perez'),
    ('Mexico', 7, 'Maria', 'Torres'),
    ('Mexico', 8, 'Javier', 'Martinez'),

    -- Thailand
    ('Thailand', 1, 'Kanjana', 'Sungngoen'),
    ('Thailand', 2, 'Siriwan', 'Pakdee'),
    ('Thailand', 3, 'Somchai', 'Boonmee'),
    ('Thailand', 4, 'Supansa', 'Nakorn'),
    ('Thailand', 5, 'Anupong', 'Sukhum'),
    ('Thailand', 6, 'Kamala', 'Phetnoo'),
    ('Thailand', 7, 'Chatri', 'Wongsa'),
    ('Thailand', 8, 'Naree', 'Kong'),

    -- Ecuador
    ('Ecuador', 1, 'Giannina', 'Lattanzio'),
    ('Ecuador', 2, 'Carlos', 'Alvarez'),
    ('Ecuador', 3, 'Isabella', 'Gomez'),
    ('Ecuador', 4, 'Luis', 'Rodriguez'),
    ('Ecuador', 5, 'Maria', 'Herrera'),
    ('Ecuador', 6, 'Sofia', 'Lopez'),
    ('Ecuador', 7, 'Diego', 'Suarez'),
    ('Ecuador', 8, 'Ana', 'Velasco'),

    -- Ivory Coast
    ('Ivory Coast', 1, 'Ange', 'NGuessan'),
    ('Ivory Coast', 2, 'Marie', 'Fofana'),
    ('Ivory Coast', 3, 'Jean', 'Kone'),
    ('Ivory Coast', 4, 'Sofia', 'Traoré'),
    ('Ivory Coast', 5, 'Luis', 'Koné'),
    ('Ivory Coast', 6, 'Awa', 'Diabaté'),
    ('Ivory Coast', 7, 'Ibrahim', 'Cissé'),
    ('Ivory Coast', 8, 'Bintou', 'Camara'),

    -- United States
    ('United States', 1, 'Carli', 'Lloyd'),
    ('United States', 2, 'Emily', 'Smith'),
    ('United States', 3, 'Aiden', 'Johnson'),
    ('United States', 4, 'Olivia', 'Williams'),
    ('United States', 5, 'Liam', 'Anderson'),
    ('United States', 6, 'Sofia', 'Brown'),
    ('United States', 7, 'Lucas', 'Jones'),
    ('United States', 8, 'Isabella', 'Davis'),

    -- Chile
    ('Chile', 1, 'Karen', 'Araya'),
    ('Chile', 2, 'Alejandro', 'Lopez'),
    ('Chile', 3, 'Sofia', 'Gonzalez'),
    ('Chile', 4, 'Carlos', 'Martinez'),
    ('Chile', 5, 'Maria', 'Ramirez'),
    ('Chile', 6, 'Luis', 'Diaz'),
    ('Chile', 7, 'Ana', 'Santos'),
    ('Chile', 8, 'Gabriel', 'Fernandez');
