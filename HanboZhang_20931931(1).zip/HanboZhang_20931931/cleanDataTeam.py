#this is a python program that cleans up the Venue.csv profile 
import csv

input_file = 'team.csv'
output_file = 'cleanedTeams.csv'
unique_rows = set()

with open(input_file, 'r') as infile, open(output_file, 'w', newline='') as outfile:
    reader = csv.reader(infile)
    writer = csv.writer(outfile)

    for row in reader:
        # Convert the row to a tuple to check for uniqueness
        row_tuple = tuple(row)
        
        if row_tuple not in unique_rows:
            unique_rows.add(row_tuple)
            writer.writerow(row)

print("CSV file cleaned and saved as", output_file)
